package game.elements.jewels;

public enum JewelType {
    RED, GREEN, BLUE;
}