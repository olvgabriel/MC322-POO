package game.elements.obstacles;

public enum ObstacleType {
    WATER, TREE;
}