package game.elements;

import game.elements.robot.Robot;

public interface Rechargable {
    
    public void recharge(Robot robot);
}