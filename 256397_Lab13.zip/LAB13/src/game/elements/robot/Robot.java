package game.elements.robot;

import game.elements.GameElement;
import game.elements.jewels.Jewel;
import game.elements.obstacles.Obstacle;
import jdk.nashorn.api.tree.Tree;

public class Robot extends GameElement {
    
    private Bag bag;
    private int pointsOfEnergy;

    public Robot(int x, int y) {
        super(x, y);
        bag = new Bag();
        this.pointsOfEnergy = 5;
        setSymbol();
    }

    private void setSymbol() {
        this.setSymbol("ME");
    }

    public void addItem(Jewel jewel) {
        bag.addItem(jewel);
    }

    public void addEnergy(GameElement e) {
        if (e.getSymbol() == "$$") {
            pointsOfEnergy += 3;
        } else if (e.getSymbol() == "JB") {
            pointsOfEnergy += 5;
        }
    }

    public void setPosition(int x, int y) {
        this.getCoordinate().changeCoordinates(x, y);
    }

    public boolean hasPointsOfEnergy() {
        return this.pointsOfEnergy > 0 ? true : false;
    }
}